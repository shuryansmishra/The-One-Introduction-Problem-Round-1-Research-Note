"""Reference policy: executable JSON adapter, never reads simulator hidden state."""
import argparse
import itertools
import json
import random
import sys
from kit import baseline_asks, baseline_match, eligibility, SOFT


def decide(request, mode='proposed'):
    state = request['state']
    memory = request.get('memory') or {}
    
    if mode in ['greedy', 'no_asks', 'random']:
        if request['phase'] == 'ask':
            return {'asks': [] if mode == 'no_asks' else baseline_asks(state), 'memory': memory}
        if mode != 'random':
            pairs = baseline_match(state)
        else:
            candidates = [m for m in state['members'] if m['available']]
            past = {tuple(sorted((i['user_a'], i['user_b']))) for i in state['introductions']}
            edges = [tuple(sorted((a['member_id'], b['member_id'])))
                     for a, b in itertools.combinations(candidates, 2)
                     if eligibility(a, b)['status'] == 'feasible'
                     and tuple(sorted((a['member_id'], b['member_id']))) not in past]
            random.Random(17 + state['day']).shuffle(edges)
            pairs, used = [], set()
            for pair in edges:
                if not used.intersection(pair):
                    pairs.append(list(pair))
                    used.update(pair)
        return {'pairs': pairs, 'memory': memory}

    # Proposed Architecture Integration
    from src.models.survival_bandit import SurvivalWeightedBandit
    from src.decision.allocator import allocate_pairs
    from src.decision.voi_ask import select_clarification_asks

    # 1. Initialize or deserialize survival bandit
    bandit_state = memory.get('bandit')
    if bandit_state:
        bandit = SurvivalWeightedBandit.from_dict(bandit_state)
    else:
        bandit = SurvivalWeightedBandit(feature_dim=len(SOFT))

    current_day = state.get('day', 0)
    past_pairs = {tuple(sorted((i['user_a'], i['user_b']))) for i in state.get('introductions', [])}

    if request['phase'] == 'ask':
        introductions = state.get('introductions', [])
        feedback = state.get('feedback', [])
        
        # 2. Classify introductions into 3 buckets (success, rejection, pending)
        classified = bandit.classify_introductions(introductions, feedback, current_day)
        
        member_lookup = {m['member_id']: m for m in state.get('members', [])}
        features_list = []
        labels = []
        
        for res in classified:
            intro = next(i for i in introductions if i['introduction_id'] == res['introduction_id'])
            m_a = member_lookup.get(intro['user_a'])
            m_b = member_lookup.get(intro['user_b'])
            if m_a and m_b:
                fa = m_a.get('fields', {})
                fb = m_b.get('fields', {})
                feat = {k: (fa.get(k) == fb.get(k) and fa.get(k) is not None) for k in SOFT}
                features_list.append(feat)
                labels.append(res['label'])
                
        # 3. Update Gaussian posteriors using survival-weighted soft labels
        bandit.update_posterior(features_list, labels)
        
        # 4. Draw Thompson weights for optimistic exploration
        rng = random.Random(42 + current_day)
        sampled_weights = bandit.sample_weights(rng)
        
        # Save state to memory before leaving ask phase
        memory['sampled_weights'] = sampled_weights
        memory['bandit'] = bandit.to_dict()
        
        # 5. VOI-optimized Clarification phase
        asks = select_clarification_asks(state, weights=sampled_weights, past_pairs=past_pairs)
        return {'asks': asks, 'memory': memory}
        
    elif request['phase'] == 'match':
        sampled_weights = memory.get('sampled_weights', {})
        # 6. Global Maximum-Weight Combinatorial Matching Phase
        pairs = allocate_pairs(state, weights=sampled_weights, past_pairs=past_pairs, day=current_day)
        return {'pairs': pairs, 'memory': memory}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--baseline', choices=['greedy', 'no_asks', 'random', 'proposed'], default='proposed')
    args = parser.parse_args()
    request = json.load(sys.stdin)
    print(json.dumps(decide(request, args.baseline), allow_nan=False))
