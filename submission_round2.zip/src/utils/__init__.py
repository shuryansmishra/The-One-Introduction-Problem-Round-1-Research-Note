"""Utilities and evaluation helpers."""
